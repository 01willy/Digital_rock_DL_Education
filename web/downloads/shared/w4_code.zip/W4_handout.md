# Week 4 · 다른 아키텍처: Swin Transformer와 3D CNN

## 1. 사전 준비

필요 패키지는 W2·W3와 같다.

```bash
pip install torch torchvision numpy matplotlib scipy
```

작업 폴더 구성:

```
<본인 작업 폴더>/
├ W4_architectures.ipynb
├ dr_utils.py
├ model_utils.py
└ data/
  └ Bentheimer_256.bin   ← data_w4.zip 압축 해제
```

```bash
jupyter notebook W4_architectures.ipynb
```

- 데이터·이웃 거리는 W3와 동일하다: **Bentheimer 사암, k=2**.
- W2·W3 체크포인트는 이번 주 필수는 아니다. 비교 기준(2D UNet)은 노트북 안에서 다시 학습한다.
- CPU 기준 노트북 전체 실행은 15분 내외다(학습 예산 90초 × 4회 + 평가).

## 2. 학습 목표

1. attention 연산(Q·K·V → 유사도 → softmax → 가중 평균)을 작은 행렬로 직접 계산한다.
2. √d 나눗셈과 softmax 포화의 관계를 설명한다.
3. 창(window) attention 이 N² 비용을 어떻게 줄이는지, 창 이동이 왜 필요한지 설명한다.
4. 3D 합성곱의 장점(부피 문맥)과 비용(파라미터 3배·느린 스텝)을 설명한다.
5. 공정 비교의 세 원칙(같은 데이터·같은 입력 정보·같은 시간 예산)과 정보 누출 점검을 적용한다.
6. 파라미터·시간·정확도 trade-off 로 세 구조의 결과를 해석한다.

## 3. 핵심 용어

| 용어 | 정의 |
|---|---|
| attention | 토큰 쌍의 유사도로 가중치를 만들어 내용(V)의 가중 평균을 내는 연산 |
| Q · K · V | 질의·색인·내용. 같은 입력에서 서로 다른 선형 변환으로 만든 세 행렬 |
| √d 나눗셈 | 점곱 점수를 √d 로 나눠 softmax 포화를 막는 안정화 |
| multi-head | 채널을 여러 head 로 나눠 서로 다른 관점의 유사도를 병렬 계산 |
| 패치 임베딩 | 4×4 픽셀을 토큰 하나로 요약하는 conv (stride 4) |
| 창 분할 (W-MSA) | 토큰 격자를 창으로 나눠 attention 을 창 안에서만 계산 |
| 창 이동 (SW-MSA) | 창을 절반 이동시켜 경계 너머 연결을 만드는 블록 |
| 3D 합성곱 | 3×3×3 커널로 슬라이스 안(x·y)과 사이(z)를 함께 보는 합성곱 |
| 공정한 입력 | 3D 입력 부피에 이웃 t±k 두 장만 채우는 설계 (2D와 같은 정보) |
| 정보 누출 | 예측 대상 근처의 정답이 입력에 섞여 지표가 부풀는 설계 오류 |

## 4. 실험 옵션 (benchmark_models)

| 인자 | 기본값 | 의미 |
|---|---|---|
| budget_s | 90 | 모델당 학습 시간 예산 (wall-clock 초) |
| k | 2 | 이웃 거리 |
| seed | 0 | 모델별 학습 시작 전 재고정 |
| models | 세 모델 | {이름: 모델} 사전으로 교체 가능 |

구조별 학습 설정(자동 적용): 합성곱 계열 Adam(lr=1e-3), transformer 계열
AdamW(lr=2e-4, weight_decay=1e-4) + gradient clipping. 손실은 모두 L1 로 동일하다.

기본 모델 크기: `UNetMini(base=16)` 117K · `SwinUNetMini(base=32)` 124K ·
`UNet3DMini(base=10)` 129K. 세 모델 모두 약 12만 파라미터로 동급이다.

## 5. 탐구 과제 (두 조 공통)

### 과제 1 (필수) — 시간 예산과 순위

`budget_s=30 / 90 / 180` 으로 공정 비교를 반복하고, 예산에 따라 세 구조의 지표와 순위가
어떻게 변하는지 표로 정리한다. 느린 구조(3D)가 예산 증가의 이득을 더 크게 보는지 확인한다.

### 과제 2 (필수) — 창 크기 trade-off

`window_size=4 / 8 / 16` 에서 SwinUNet 의 epoch 수·|Δφ|·SSIM 을 비교하고, "보는 범위 ↔
계산 비용" 관점에서 결과를 해석한다. (window_size 는 토큰 격자 크기 H/4 의 약수여야 한다)

### 과제 3 (선택) — 파라미터 동급의 다른 지점

`UNetMini(base=8/16/32)`, `SwinUNetMini(base=16/32/48)`, `UNet3DMini(base=8/10/12)` 로
크기를 바꿔 "파라미터 수 vs 지표" 곡선을 그리고, 같은 파라미터에서 구조 간 격차가
유지되는지 확인한다.

### 과제 4 (선택, 심화) — 정보 누출 실험

`Slice3DDataset` 을 복사해 가운데 이웃(t±1)도 입력에 채우는 잘못된 버전을 만들어 학습해
본다. 지표가 얼마나 부풀는지 측정하고, 왜 이것이 실력이 아닌지 한 문단으로 설명한다.
(실제 배포 상황에는 t±1 이 존재하지 않는다)

## 6. 다음 주차 사전 준비

- **W5: 한계 극복 기법** — 구조를 바꾸는 대신 같은 2D UNet 을 쓰는 방법을 바꾼다.
  세 직교축 예측의 융합(tri-axis), 여러 k 동시 학습, 증강·후처리.
- 이번 주 노트북의 `results` 표(특히 2D UNet 의 |Δφ|·SSIM)를 기록해 두면 W5 에서
  개선 폭을 비교할 수 있다.

## 7. 자주 발생하는 문제

| 증상 | 해결 |
|---|---|
| shape 오류 (32의 배수) | SwinUNet 입력 H·W는 32의 배수여야 함. patch_size=64 유지 |
| SwinUNet 손실 발산·지표 붕괴 | 학습률 과대. benchmark_models 의 구조별 기본 설정 사용 |
| §5 실행이 너무 김 | budget_s 축소, 또는 GPU 환경에서 실행 (DEVICE 자동 감지) |
| 3D 평가가 느림 | 정상 (슬라이스마다 부피 forward). CPU 1~2분 수준 |
| 한글 라벨 깨짐 | setup_plot_style() 실행 여부 확인 |
| 메모리 부족 | batch_size 축소 (benchmark_models 인자) |
